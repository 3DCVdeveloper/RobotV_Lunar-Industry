 
from pyorbbecsdk import *
import Jetson.GPIO as GPIO
import cv2
import numpy as np
from utils import frame_to_bgr_image
import sys
import argparse

GPIO.setmode(GPIO.BOARD)
dk=[40,38,37,36,35,33]
for i in dk:
    GPIO.setup(i, GPIO.OUT)

"""
GPIO.setup(40, GPIO.OUT)# +-X
GPIO.setup(38, GPIO.OUT)# +-Y
GPIO.setup(37, GPIO.OUT)# +-k
GPIO.setup(36, GPIO.OUT)# x
GPIO.setup(35, GPIO.OUT)# y
GPIO.setup(33, GPIO.OUT)# k
"""


ESC_KEY = 27

#判断与抓取点坐标差多少
def paduansfzq(xyk):
    zqd=[300,150,300] #抓取点
    pdfw=[20,20,50]   #容错范围

    for i in range(3):
        scio=zqd[i]-xyk[i]
        if scio>0:
            GPIO.output(dk[i], GPIO.HIGH)
        else:
            GPIO.output(dk[i], GPIO.LOW)
    
    for i in range(3):
        scio=zqd[i]-xyk[i]
        if abs(scio)<pdfw[i]:
            GPIO.output(dk[i+3], GPIO.HIGH)
        else:
            GPIO.output(dk[i+3], GPIO.LOW)
        
        
def draw_apple_bounding_box(frame, bounding_box):
    """在图像上绘制苹果的矩形框"""
    x1, y1 = bounding_box[0]
    x2, y2 = bounding_box[1]
    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)  # 绿色边框，宽度为2像素

#测量中心深度
def zxcl(abeu,ejiof,shz):
    x= int((abeu[1][0]-abeu[0][0])/2+abeu[0][0])
    y= int((abeu[1][1]-abeu[0][1])/2+abeu[0][1])
    sd=shz[y][x]
    return x,y,sd

#以二值图与深度图和识别区域来筛选的有效像素并求出平均值
def erztqd(abeu,ejiof,shz):
    cs=0
    zsd=0
    a,b,c,d=int(abeu[0][0]),int(abeu[1][0]),int(abeu[0][1]),int(abeu[1][1])
    for x in range(a,b):
        for y in range(c,d):
            if int(ejiof[y][x])==255 and int(shz[y][x])!=0:
                cs+=1
                zsd+=shz[y][x]
    sd=0
    if cs!=0:
        sd=zsd/cs
    x=(b-a)/2+a
    y=(d-c)/2+c
    return  x,y,sd



def find_apple_in_frame(frame):
    # 将帧转换为HSV颜色空间
    hsv_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # 在HSV中定义红色的范围
    lower_red = np.array([0, 250, 18])
    upper_red = np.array([0, 255, 48])

    # 为红色创建掩码
    red_mask = cv2.inRange(hsv_frame, lower_red, upper_red)

 #   cv2.imshow('red_mask', red_mask)
    # 在掩码中找到轮廓
    contours, _ = cv2.findContours(red_mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    for contour in contours:
        # 计算每个轮廓的面积
        area = cv2.contourArea(contour)

        if area > 500:
            # 计算轮廓的边界框（bounding box）
            x, y, w, h = cv2.boundingRect(contour)
            wa=(x, y) #左上角
            wb=(x + w - 1, y + h - 1)   #右下角

            # 返回边界框的左上角和右下角坐标
            return (wa, wb),red_mask

    return None

def main(argv):
    pipeline = Pipeline()
    device = pipeline.get_device()
    device_info = device.get_device_info()
    device_pid = device_info.get_pid()
    config = Config()
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mode",
                        help="align mode, HW=hardware mode,SW=software mode,NONE=disable align",
                        type=str, default='HW')
    parser.add_argument("-s", "--enable_sync", help="enable sync", type=bool, default=True)
    args = parser.parse_args()
    align_mode = args.mode
    enable_sync = args.enable_sync
    try:
        profile_list = pipeline.get_stream_profile_list(OBSensorType.COLOR_SENSOR)
        color_profile = profile_list.get_default_video_stream_profile()
        config.enable_stream(color_profile)
        profile_list = pipeline.get_stream_profile_list(OBSensorType.DEPTH_SENSOR)
        assert profile_list is not None
        depth_profile = profile_list.get_default_video_stream_profile()
        assert depth_profile is not None
        print("color profile : {}x{}@{}_{}".format(color_profile.get_width(),
                                                   color_profile.get_height(),
                                                   color_profile.get_fps(),
                                                   color_profile.get_format()))
        print("depth profile : {}x{}@{}_{}".format(depth_profile.get_width(),
                                                   depth_profile.get_height(),
                                                   depth_profile.get_fps(),
                                                   depth_profile.get_format()))
        config.enable_stream(depth_profile)
    except Exception as e:
        print(e)
        return
    if align_mode == 'HW':
          if device_pid == 0x066B:
            #Femto Mega does not support hardware D2C, and it is changed to software D2C
             config.set_align_mode(OBAlignMode.SW_MODE)
          else:
             config.set_align_mode(OBAlignMode.HW_MODE)
    elif align_mode == 'SW':
        config.set_align_mode(OBAlignMode.SW_MODE)
    else:
        config.set_align_mode(OBAlignMode.DISABLE)
    if enable_sync:
        try:
            pipeline.enable_frame_sync()
        except Exception as e:
            print(e)
    try:
        pipeline.start(config)
    except Exception as e:
        print(e)
        return
    while True:
        try:
            frames: FrameSet = pipeline.wait_for_frames(100)
            if frames is None:
                continue
            color_frame = frames.get_color_frame()

            if color_frame is None:
                continue
            # covert to RGB format
            color_image = frame_to_bgr_image(color_frame)
            if color_image is None:
                print("failed to convert frame to image")
                continue
            depth_frame = frames.get_depth_frame()
            if depth_frame is None:
                continue

            width = depth_frame.get_width()
            height = depth_frame.get_height()
            scale = depth_frame.get_depth_scale()

            depth_data = np.frombuffer(depth_frame.get_data(), dtype=np.uint16)
            depth_data = depth_data.reshape((height, width))
            depth_data = depth_data.astype(np.float32) * scale
     #       print (depth_data[150][300])
            depth_image = cv2.normalize(depth_data, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
            depth_image = cv2.applyColorMap(depth_image, cv2.COLORMAP_JET)
            # overlay color image on depth image
            depth_image = cv2.addWeighted(color_image, 0.5, depth_image, 0.5, 0)
            
            apple_bounding_box = find_apple_in_frame(color_image)
            if find_apple_in_frame(color_image)!=None:
                apple_bounding_box = find_apple_in_frame(color_image)[0]
                
                xyk=erztqd(apple_bounding_box,find_apple_in_frame(color_image)[1],depth_data)
                paduansfzq(list(xyk))
                print(list(xyk))
                
                
                
            # 如果找到了苹果，则在图像上绘制矩形框
            if apple_bounding_box is not None:
                draw_apple_bounding_box(color_image, apple_bounding_box)
                draw_apple_bounding_box(depth_image, apple_bounding_box)               
            cv2.imshow("SylignViewer ", color_image)  
            cv2.imshow("SyncAlignViewer ", depth_image)
            
            key = cv2.waitKey(1)
            if key == ord('q') or key == ESC_KEY:
                break
        except KeyboardInterrupt:
            break
    pipeline.stop()


if __name__ == "__main__":
    main(sys.argv[1:])
