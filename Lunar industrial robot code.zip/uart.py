import serial
from time import sleep,time
from threading import Thread


class UART(Thread):
    def __init__(self):
        super().__init__()
        # config uart
        self.ser = serial.Serial("/dev/ttyTHS0", 9600,timeout=0.05,write_timeout=0.01)
        # save param
        self.writeBool = False
        self.readBool = False
        self.whetherRun = False
        self.threadRun = True
        # save data
        self.readData = ''
        self.writeData = ''

        if self.ser.is_open:
            print("UART: YES")
            self.start()
        else:
            print("UART: NO")

        return None
    
    def run(self):
        while self.threadRun:
            if self.readBool:
                self.whetherRun = True
                # self.readData = self.runRead()
                self.readData = self.runRead()
                self.whetherRun = False
                self.readBool = False

            if self.writeBool:
                self.whetherRun = True
                self.runWrite(self.writeData)
                self.whetherRun = False
                self.writeBool = False
            
            sleep(0.01)

        return None
    
    def read(self):
        """
        use readParam get data
        """
        self.readBool = True
        return None
    
    def write(self, data):
        """
        data: data is a string
        """
        self.writeBool = True
        self.writeData = data
        return None

    def readParam(self):
        sleep(0.1)
        while self.whetherRun:
            sleep(0.01)
        return self.readData

    def runRead(self):
        # send head
        while True:
            self.ser.write('>'.encode())
            # wait one cycle
            if self.ser.read(1) == b'>':
                break
        
        total = ''
        while True:
            detect = self.ser.read(1)
            if detect != b'':
                if detect != b'>':
                    total += detect.decode()

                    continue
                break

        return total
    
    def runWrite(self, param):
        while True:
            self.ser.write('<'.encode())
                # wait ten cycle
            if self.ser.read(1) == b'<':
                break

        startTime = time()
        self.ser.write(param.encode())
        sleeptime = 0.02 - (time() - startTime)
        sleep(sleeptime if sleeptime > 0 else 0)

        return None
    
    def close(self):
        if self.ser.is_open:
            self.ser.close()
            self.threadRun = False

        return None